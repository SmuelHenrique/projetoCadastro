package com.example.myapllication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class editarActivity extends AppCompatActivity {
    EditText txtEmailEditar,txtSenhaEditar, txtSenhaConfirmarEditar;
    Button btnExcluir, btnEditar;
    private SQLiteDatabase bancoDados;
    Intent intent;
    String login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);
        intent = getIntent();
        login = intent.getStringExtra("login");

        txtEmailEditar = (EditText) findViewById(R.id.txtEmailEditar);
        txtSenhaEditar = (EditText) findViewById(R.id.txtSenhaEditar);
        txtSenhaConfirmarEditar = (EditText) findViewById(R.id.txtSenhaConfirmarEditar);
        btnExcluir = (Button) findViewById(R.id.btnExcluir);
        btnEditar = (Button) findViewById(R.id.btnEditar);

        carregarDados();

        btnExcluir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                excluirCdastro();
            }
        });

        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                atualizarCadastro();
            }
        });
    }

    public void excluirCdastro(){
        try{
            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
            String sql = "DELETE FROM usuario WHERE login=?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1,login);
            stmt.executeUpdateDelete();
            bancoDados.close();
            abrirTelaPrincipal();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void atualizarCadastro(){
            //Intent intent = getIntent();
            //String id = intent.getIntExtra("id",0);
            String valueSenha;
            if (txtSenhaEditar.getText().toString().equals(txtSenhaConfirmarEditar.getText().toString())){
                valueSenha = txtSenhaEditar.getText().toString();
                try{
                    bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
                    String sql = "UPDATE usuario SET senha=? WHERE login=?";
                    SQLiteStatement stmt = bancoDados.compileStatement(sql);
                    stmt.bindString(1,valueSenha);
                    stmt.bindString(2,login);
                    stmt.executeUpdateDelete();
                    bancoDados.close();
                    abrirTelaPrincipal();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else
                Toast.makeText(this, "As senhas devem ser iguais", Toast.LENGTH_SHORT).show();

    }

    public void carregarDados(){
        try {
            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM usuario WHERE login = '" + login + "'", null);
            cursor.moveToFirst();
            txtEmailEditar.setText(cursor.getString(0));
            txtSenhaEditar.setText(cursor.getString(1));
            txtSenhaConfirmarEditar.setText(cursor.getString(1));

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaPrincipal(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}