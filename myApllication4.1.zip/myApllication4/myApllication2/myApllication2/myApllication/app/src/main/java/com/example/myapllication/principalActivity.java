package com.example.myapllication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class principalActivity extends AppCompatActivity {
    EditText txtNomeCompromisso,txtData, txtDescricaoCompromisso;
    Button btnCadastrarCompromissos, btnVerCompromissos, btnConta;
    Intent intent;
    String login;
    // private SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        intent = getIntent();
        login = intent.getStringExtra("login");

        txtNomeCompromisso = (EditText) findViewById(R.id.txtNomeCompromisso);
        txtData = (EditText) findViewById(R.id.txtData);
        txtDescricaoCompromisso = (EditText) findViewById(R.id.txtDescricaoCompromisso);
        btnCadastrarCompromissos = (Button) findViewById(R.id.btnInserir);
        btnConta = (Button) findViewById(R.id.btnConta);
        btnVerCompromissos = (Button) findViewById(R.id.btnVerCompromissos);



        btnCadastrarCompromissos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnVerCompromissos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTelaEditar();
            }
        });

    }
    public void abrirTelaEditar(){
        Intent intent = new Intent(this, editarActivity.class);
        intent.putExtra("login",login);
        startActivity(intent);
    }

}